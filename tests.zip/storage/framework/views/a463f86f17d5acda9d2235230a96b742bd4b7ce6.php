<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="bgc-white bd bdrs-3 p-20 mB-20">
                    <div class="row">
                        <div class="col-md-12">
                            <h4 class="c-grey-900 mB-20">Education</h4>
                        </div>
                    </div>
                    <table class="table table-bordered table-striped table-sm">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Education</th>
                                <th scope="col">Category</th>
                                <th scope="col">Sub Category</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($education->firstItem() + $k); ?></th>
                                <td><?php echo e($edu->name); ?></td>
                                <td><?php echo e($edu->category); ?></td>
                                <td><?php echo e($edu->sub_category); ?></td>
                                <td>
                                    <a href="<?php echo e(route('education.edit', $edu)); ?>">Edit</a>     /
                                    <a href="<?php echo e(route('education.edit', $edu)); ?>">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-md-4">
                <?php echo $__env->make('admin.education.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\roster\resources\views/admin/education/index.blade.php ENDPATH**/ ?>